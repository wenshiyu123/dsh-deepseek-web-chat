# v1.0.1 · 图标与侧栏入口改版

发布日：2026-11-17

## 这次改了什么

- **重绘插件图标**：从「蓝色圆角底板 + 白色气泡」改为 DSH 官方插件图标的语言——36×36、透明底、`#7AC2FF → #4A65E8` 渐变气泡 + 三个输入点。插件卡片、插件详情页里的观感现在和官方插件一致。
- **侧栏入口与标题栏同步换新**：侧栏底部「DeepSeek 对话」和浮窗标题栏的小图标，从「两行文字的小气泡」换成同一个三点气泡（轮廓版，颜色继承侧栏，浅色/深色/悬停/打开时都自动适配）。
- **侧栏入口改成真正的按钮**：常态一层 6% 淡底 + 圆角，悬停加深到 10%，浮窗打开时品牌色 14% 浅底 + 1px 内描边 + 文字/图标变品牌蓝；尺寸按 DSH 侧栏行对齐（32px 行高、6px 间距、14px 字号、3px 描边内缩），收起栏为 36×36 方块。
- **只动外观**：`client.js` 只改了图标字形与入口按钮的样式与尺寸，浮窗行为、语言包、登录快照逻辑一律未动。已经用着 1.0.0 的用户升级后，已记住的登录状态不受影响。

## 安装与升级

- 新装：DSH → 设置 → 插件 → 添加插件 → `https://github.com/wenshiyu123/dsh-deepseek-web-chat`
- 已在 1.0.0：在插件页对 `dsh-deepseek-web-chat` 执行更新（Git 来源的插件从 Discover/更新入口操作），或卸载后重装。登录快照存在 DSH 应用数据里，卸载重装不会丢。
- 从附件安装：`dsh-deepseek-web-chat-1.0.1.tgz` 用 `dsh plugin add <本地路径>` 安装；`dsh-deepseek-web-chat-1.0.1.zip` 解压后添加该目录即可。
- 插件卡片图标是静态资源，刷新插件页即可；**侧栏入口的图标和按钮样式写在 `client.js` 里，需要重载页面（`Ctrl+R`）或完全退出 DSH 再启动**才会生效。

## 包内容

`index.js`、`client.js`、`cordis.patch.yml`、`locale/en.json`、`locale/zh.json`、`icon.svg`、`docs/preview.png`、`README.md`、`LICENSE`、`package.json`。

附件的 SHA-256 见 `SHA256SUMS.txt`。

## English

Version 1.0.1 only changes appearance: the plugin icon becomes a 36×36 transparent gradient bubble with three typing dots in the official DSH plugin-icon style, the sidebar footer and window title bar use the matching outline glyph, and the sidebar entry is restyled as a button — subtle resting fill, brand-tinted open state with an inner ring, and DSH sidebar metrics (32px row, 6px gap, 14px label, 36px rail square). Plugin behaviour, configuration, locale and the stored sign-in snapshot are unchanged.
