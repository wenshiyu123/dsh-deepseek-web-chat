# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.1] - 2026-11-17

### Changed

- Redrew the plugin icon in the official DSH plugin-icon language: a 36×36 transparent-background gradient glyph (chat bubble with three typing dots) replaces the blue rounded tile, so plugin cards and the plugin details page sit beside first-party plugins consistently.
- Updated the in-app glyph behind the sidebar footer entry and the window title bar to the same three-dot bubble outline, so the entry matches the plugin artwork and still follows the sidebar's `currentColor`.
- Restyled the sidebar footer entry as a button: a subtle resting fill, a brand-tinted open state with an inner ring, and DSH sidebar metrics (32px row, 6px gap, 14px label, 3px paint inset, 36×36 rail square).

No functional, configuration, locale or stored sign-in changes; the diff is limited to `BubbleIcon` and the entry's CSS.

## [1.0.0] - 2026-11-06

### Added

- Floating window hosting the official DeepSeek web chat (`chat.deepseek.com`) inside DeepSeek Harness desktop.
- Sidebar footer entry, slide-in/slide-out motion, drag, resize, right-edge following, and content-area maximize with a labelled restore control.
- Remembered sign-in: the site's local storage is snapshotted locally after login and restored on the next open or app restart.
- Isolated embedded page: sandboxed webview without Node or preload access to the harness.
- Simplified Chinese and English UI copy.
- GitHub-ready repository files: README, MIT license, contributing and security guides, changelog, CI, and issue template.
